from lib.nulis.nulis import tulis, imageToBase64
